// Setting up express web server
// import express and cors modules, express to build rest API
// add request body parser and cors middleware using app.use()
// cors is the middleware between your frontend and back
const port = 8080;
const express = require("express");
// const routes = require("./router/routes.js");
const app = express();
require("dotenv").config();
// console.log(process.env);
const mysqlcon = require("./mysqlcon.js");
const cors = require("cors");
const controller = require("./controller.js");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const { Console } = require("console");

//Mailtrap
// const { MailtrapClient } = require("mailtrap");

// // For this example to work, you need to set up a sending domain,
// // and obtain a token that is authorized to send from the domain
// const TOKEN = "your-api-token";
// const SENDER_EMAIL = "sender@yourdomain.com";
// const RECIPIENT_EMAIL = "recipient@email.com";
// const client = new MailtrapClient({ token: TOKEN });
// const sender = { name: "Mailtrap Test", email: SENDER_EMAIL };

// client
//   .send({
//     from: sender,
//     to: [{ email: RECIPIENT_EMAIL }],
//     subject: "Hello from Mailtrap!",
//     text: "Welcome to Mailtrap Sending!",
//   })
//   .then(console.log, console.error);

// var mailOptions = {
//   from: "youremail@gmail.com",
//   to: "myfriend@yahoo.com",
//   subject: "Sending Email using Node.js",
//   text: "That was easy!",
// };

// transporter.sendMail(mailOptions, function (error, info) {
//   if (error) {
//     console.log(error);
//   } else {
//     console.log("Email sent: " + info.response);
//   }
// });

//app.use to setup middleware for your path
app.use(
  cors({
    origin: ["http://localhost:3000"],
    methods: ["GET", "POST"],
    credentials: true,
    optionSuccessStatus: 200,
  })
); //to parse requests of type app/json

app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true })); //simple routing
app.use(express.json()); //to parse requests of type app/http-url
app.use(
  session({
    key: "userId",
    secret: "test123",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24 * 1000,
    },
  })
);

app.get("/login", (req, res) => {
  if (req.session.user) {
    console.log(req.session.user, "session here");
    res.send({ loggedIn: true, user: req.session.user });
  } else {
    console.log(req.session.user, "session failed");
    res.send({ loggedIn: false });
  }
});

app.get("/logout", (req, res) => {
  console.log("requested logout");
  // req.logout();
  //destroy session data
  delete req.session.id;
  delete req.session.user;
  delete req.session.email;
  req.session.user = "";
  req.session.email = "";
  res.clearCookie("userId");
  res.send({ loggedIn: false });
  res.end();
});

app.get("/createuser", (req, res) => {
  if (req.session.user) {
    res.send({ loggedIn: true, user: req.session.user });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/dashboard", (req, res) => {
  if (req.session.user) {
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/editprofile", (req, res) => {
  // let refresh = await controller.refreshprofileFunction(username);
  // if (res) {
  //   email = res.email;
  if (req.session.user) {
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
    console.log(req.session.user);
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/usermgmt", (req, res) => {
  if (req.session.user) {
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/getedituser", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/viewallusers", (req, res) => {
  if (req.session.user) {
    console.log(req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/usergroups", (req, res) => {
  if (req.session.user) {
    console.log("usergroups sessions");
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/usermgmt", (req, res) => {
  if (req.session.user) {
    console.log("usergroups sessions");
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/createapp", (req, res) => {
  if (req.session.user) {
    console.log("create application sessions");
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/appdashboard", (req, res) => {
  if (req.session.user) {
    console.log("create application sessions");
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/editapp", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/createplan", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/createtask", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/plantaskboard", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/edittaskpage", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

app.get("/editplan", (req, res) => {
  if (req.session.user) {
    console.log("edituser response", req.session.user);
    res.send({ loggedIn: true, user: req.session.user, email: req.session.email });
  } else {
    res.send({ loggedIn: false });
  }
});

//retrieve admin list
//retrieving admins
app.get("/admin", async (req, res) => {
  userid = req.session.user;
  let groupname = "%Admin%";
  console.log(groupname);
  console.log(userid, "USERNAME FOR ADMIN CHECKS");
  let results = await controller.checkgroupFunction(userid, groupname);
  if (results == 1) {
    res.send({ message: "Success! User is an admin", results: userid, admin: true, loggedIn: true });
  } else if (results == 0) {
    res.send({ message: "Failure not an admin", results: results, admin: false });
  }
});
// if (results[i].username === req.session.user) {
//   console.log("SUCCESS for admin verification");
//   const adminuser = results[i].username;
//   admin:true;
// }
// res.send({ message: "Success! User is an admin", results: adminuser, admin: true, loggedIn: true });
// } else {
//   res.send({ message: "Failure not an admin", results: results, admin: false });
// }

app.post("/login", async (req, res) => {
  const username = req.body.username; //req is from axios
  const password = req.body.password;
  console.log(username);
  console.log(password);
  let result = await controller.checkpwFunction(username);
  if (result == "0") {
    console.log("Invalid Authentication!");
    res.send({ message: "Invalid Authentication. Try Again.", result: result, loggedIn: false });
  } else {
    hashed = result[0].password;
    req.session.user = result[0].username;
    req.session.email = result[0].email;
    email = result[0].email;
    console.log("Result", result);
    console.log(hashed, "hashedpw");
    bcrypt.compare(password, hashed, function (err, result) {
      if (result == "1") {
        console.log("PW Matched");
        res.send({ message: "PW Check Matched, Login Successful!", result: result, email, username: req.session.user, loggedIn: true });
      } else if (result == "0") {
        console.log("Invalid Authentication!");
        res.send({ message: "Invalid Authentication. Try Again.", result: result, loggedIn: false });
      } else {
        console.log("Error in querying for registering to database");
        res.send({ message: "Unsuccessful query", result: result });
      }
    });
  }
});

app.post("/createuser", async (req, res) => {
  const username = req.body.username; //req is from axios
  const password = req.body.password;
  const email = req.body.email;
  console.log(username);
  bcrypt.genSalt(saltRounds, function (err, salt) {
    bcrypt.hash(password, salt, async function (err, hash) {
      //returns hash
      // console.log(hash);
      // let checkduplicate = controller.createuserdupeFunction(username);
      // console.log(checkduplicate, "HIII");
      // if (checkduplicate.length > 0) {
      //   console.log(checkduplicate, "main message ERROR ERROR");
      //   res.send({ message: "Unsucessful creation, Duplicated", results: checkduplicate });
      // } else {
      //   console.log("all clear, proceed to insert to sql");
      //register users
      let register = await controller.createuserFunction(username, hash, email);
      console.log(register.data + "register data output");
      if (register == "1") {
        console.log(register, "Main Message Successful creation");
        //   res.send(results);
        res.send({ message: "Successful Creation of User!", results: register });
      } else if (register == "0") {
        res.send({ message: "Unsuccessful. Duplicate Data. Try Different Username", results: register });
      } else {
        console.log("Error in querying for registering to database");
        res.send({ message: "Unsuccessful query", results: register });
      }
      //returns salt
    });
    if (err) {
      console.log(err);
      res.send({ message: "Error in salting pw", results: error });
    }
  });
});
// console.log(username);
// console.log(email);
// // console.log(register[0], "main");

app.post("/editprofile", async (req, res) => {
  const username = req.session.user;
  const newpassword = req.body.password;
  const newemail = req.body.email; //req is from axios
  console.log(username);
  bcrypt.genSalt(saltRounds, function (err, salt) {
    bcrypt.hash(newpassword, salt, function (err, hash) {
      let results = controller.editprofileFunction(username, hash, newemail);
      if (res) {
        console.log(results, "main");
        //   res.send(results);
        res.send({ message: "Success!", results: results });
      }
    });
  });
});

app.post("/edituser/:username", async (req, res) => {
  //****Retrieve particulars of user1 first****
  const user = req.body.user;
  console.log(user, "user's username");
  let results = await controller.fetchEditUserFunction(user);
  if (res) {
    //response must be username and email
    console.log(results, "main");
    //   res.send(results);
    res.send({ message: "Success! Retrieved particulars of user", results: results });
  } else {
    console.log("Error");
    res.send({ message: "Error! in retrieving particulars of user", results: results });
  }
});

//to edit user
app.post("/edituserr", async (req, res) => {
  const user = req.body.user;
  const newpassword = req.body.password;
  const newemail = req.body.email; //req is from axios
  console.log(user);
  console.log(newpassword);
  console.log(newemail);
  bcrypt.genSalt(saltRounds, function (err, salt) {
    bcrypt.hash(newpassword, salt, function (err, hash) {
      let results = controller.edituserFunction(user, hash, newemail);
      if (res) {
        console.log(results, "main");
        //   res.send(results);
        res.send({ message: "Successfully changed user details!", results: results });
      }
    });
  });
});

//View all Users at Edit User
app.get("/viewalluserss", async (req, res) => {
  //****Retrieve usergroup list first****
  let results = await controller.viewallusersFunction();
  if (res) {
    //response must be username and email
    // console.log(results, "mainjs for viewusers");
    //   res.send(results);
    res.send({ message: "Success! Retrieved users", results: results });
  }
});

// View Usergroups
app.get("/viewusergroups", async (req, res) => {
  //****Retrieve usergroup list first****
  let results = await controller.viewusergroupFunction();
  if (res) {
    //response must be username and email
    // console.log(results, "mainjs for viewusergroups");
    //   res.send(results);
    res.send({ message: "Success! Retrieved user groups", results: results });
  }
});

// View Usergroups
app.get("/viewuserroles", (req, res) => {
  //****Retrieve usergroup list first****
  let results = controller.viewuserrolesFunction();
  if (res) {
    //response must be username and email
    // console.log(results, "mainjs for viewusergroups");
    //   res.send(results);
    res.send({ message: "Success! Retrieved user roles only", results: results });
  }
});

//Create usergroup
app.post("/creategroups", async (req, res) => {
  const role = req.body.role;
  const groupstatus = "1";
  console.log(groupstatus);
  console.log(role);
  let results = await controller.createusergroupFunction(role, groupstatus);
  if (results == "1") {
    console.log(results, "Main Message Successful creation of User group");
    res.send({ message: "Successful Creation of User!", results: results });
  } else if (results == "0") {
    res.send({ message: "Unsuccessful. Duplicate Data. Try Different Name", results: results });
  } else {
    console.log("Error in querying for registering to database");
    res.send({ message: "Unsuccessful query", results: results });
  }
});

app.post("/usergroupscheckboxes", async (req, res) => {
  const checks = req.body.checkbox;
  console.log(checks, "from frontend");
  // const check = checks.replaceAll('"', "");
  let results = await controller.groupscheckboxFunction(checks);
  if (res) {
    console.log(results, "main");
    //   res.send(results);
    res.send({ message: "Successfully changed user details!", results: results });
  } else {
    console.log("Error");
    // res.send({ message: "Error! in creating user group", results: results });
  }
});

//Edit-Users CheckBoxes
app.post("/editusercheckboxes", async (req, res) => {
  const user = req.body.user;
  const checkedrole = req.body.checkbox;
  console.log(user);
  console.log(checkedrole, "from frontend");
  let results = await controller.editusercheckboxFunction(checkedrole, user);
  if (res) {
    console.log(results, "main");
    //   res.send(results);
    res.send({ message: "Successfully changed user details!", results: results });
  } else {
    console.log("Error");
    // res.send({ message: "Error! in creating user group", results: results });
  }
});

// View Usergroups
app.get("/usergetcheckedboxes", async (req, res) => {
  //****Retrieve usergroup list first****
  let results = await controller.usergetcheckedboxesFunction();
  if (res) {
    //response must be username and email
    // console.log(results, "mainjs for viewusergroups");
    //   res.send(results);
    res.send({ message: "Success! Retrieved roles for each user", results: results });
  }
});

// Diable and Enable Groups
app.post("/userscheckboxes", async (req, res) => {
  const checks = req.body.checkbox;
  console.log(checks, "from frontend");
  const check = checks.replaceAll('"', "");
  const checkboxesuser = check.replace(/[[\]]/g, "");
  console.log(checkboxesuser);
  let results = await controller.userscheckboxFunction(checkboxesuser);
  if (res) {
    console.log(results, "main");
    //   res.send(results);
    res.send({ message: "Successfully changed user details!", results: results });
  } else {
    console.log("Error");
    // res.send({ message: "Error! in creating user group", results: results });
  }
});

app.listen(port, () => {
  console.log("Express server listening on port" + port);
});

app.post("/createapp", async (req, res) => {
  const acronym = req.body.acronym; //req is from axios
  const desc = req.body.desc;
  const rno = req.body.rno;
  const startdate = req.body.startdate;
  const enddate = req.body.enddate;
  const permitcreate = req.body.permitcreate;
  const permitopen = req.body.permitopen;
  const permittodo = req.body.permittodo;
  const permitdoing = req.body.permitdoing;
  const permitdone = req.body.permitdone;
  console.log(permitopen, "mypermit OPEN");
  console.log(permittodo, "mypermit todo");
  console.log(permitdoing, "mypermit doing");
  console.log(permitdone, "mypermit done");
  // console.log(desc);
  // console.log(rno);
  // console.log(startdate);
  // console.log(enddate);
  let appcreate = await controller.createappFunction(acronym, desc, rno, startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone);
  if (appcreate == "1") {
    console.log(appcreate, "Main Message Successful creation");
    res.send({ message: "Successful Creation of Application!", results: appcreate });
  } else if (appcreate == "0") {
    res.send({ message: "Unsuccessful. Duplicate Data. Try Different App Name", results: appcreate });
  } else {
    console.log("Error in querying for registering to database");
    res.send({ message: "Unsuccessful query", results: appcreate });
  }
});

// app.post("/apppermits", async (req, res) => {
//   const acronym = req.body.acronym; //req is from axios
//   const permitopen = req.body.permitopen;
//   const permittodo = req.body.permittodo;
//   const permitdoing = req.body.permitdoing;
//   const permitdone = req.body.permitdone;
//   console.log(acronym);
//   console.log(permittodo);
//   let appcreate = await controller.apppermitsFunction(acronym, permitopen, permittodo, permitdoing, permitdone);
//   if (appcreate == "1") {
//     console.log(appcreate, "Main Message Successful creation");
//     res.send({ message: "Successful Creation of Application!", results: appcreate });
//   } else if (appcreate == "0") {
//     res.send({ message: "Unsuccessful. Duplicate Data. Try Different App Name", results: appcreate });
//   } else {
//     console.log("Error in querying for registering to database");
//     res.send({ message: "Unsuccessful query", results: appcreate });
//   }
// });

//View all apps
app.get("/viewapps", async (req, res) => {
  //****Retrieve usergroup list first****
  let results = await controller.viewappsFunction();
  if (res) {
    //response must be username and email
    // console.log(results, "mainjs for viewusers");
    //   res.send(results);
    res.send({ message: "Success! Retrieved users", results: results });
  }
});

app.post("/editapp/:acronym", async (req, res) => {
  //****Retrieve particulars of user1 first****
  const acronym = req.body.acronym;
  console.log(acronym, "app's acronym");
  let results = await controller.fetchEditAppFunction(acronym);
  if (res) {
    //response must be username and email
    console.log(results, "main");
    //   res.send(results);
    res.send({ message: "Success! Retrieved particulars of the app", results: results });
  } else {
    console.log("Error");
    res.send({ message: "Error! in retrieving particulars of the app", results: results });
  }
});

//to edit user
app.post("/editapps", async (req, res) => {
  const acronym = req.body.acronym;
  const desc = req.body.desc;
  const startdate = req.body.startdate;
  const enddate = req.body.enddate; //req is from axios
  const permitcreate = req.body.permitcreate;
  const permitopen = req.body.permitopen;
  const permittodo = req.body.permittodo;
  const permitdoing = req.body.permitdoing;
  const permitdone = req.body.permitdone;
  console.log("DADADADADADADADAD :", permitcreate);
  console.log(acronym);
  console.log(desc);
  console.log(startdate);
  console.log(enddate);
  let results = await controller.editappsFunction(desc, startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym);
  if (results == "0") {
    console.log(results, "main");
    res.send({ message: "Failed to change application details!", results: results });
  } else if (results == "1") {
    console.log(results, "main");
    res.send({ message: "Successfully changed application details!", results: results });
  } else {
    console.log("There is a problem");
  }
});

// View Usergroups
app.get("/viewappgroups", async (req, res) => {
  //****Retrieve usergroup list first****
  let results = await controller.viewappgroupsFunction();
  if (res) {
    //response must be username and email
    // console.log(results, "mainjs for viewusergroups");
    res.send({ message: "Success! Retrieved user groups", results: results });
  }
});

app.post("/createplan/:acronym", async (req, res) => {
  const acronym = req.body.acronym; //req is from axios
  const desc = req.body.desc;
  const mvpname = req.body.mvpname;
  const startdate = req.body.startdate;
  const enddate = req.body.enddate;
  console.log(mvpname);
  console.log(acronym);
  console.log(desc);
  console.log(startdate);
  console.log(enddate);
  let plancreate = await controller.createplanFunction(mvpname, desc, startdate, enddate, acronym);
  if (plancreate == "1") {
    console.log(plancreate, "Main Message Successful creation");
    res.send({ message: "Successful Creation of a Plan!", results: plancreate });
  } else if (plancreate == "0") {
    res.send({ message: "Unsuccessful. Duplicate Data. Try Different Plan name", results: plancreate });
  } else {
    console.log("Error in querying for registering to database");
    res.send({ message: "Unsuccessful query", results: plancreate });
  }
});

// View all Users at Edit User
app.post("/viewplans/:acronym", async (req, res) => {
  //****Retrieve plans list first****
  const acronym = req.body.acronym;
  console.log(acronym);
  let results = await controller.viewplansFunction(acronym);
  if (res) {
    // console.log(results, "mainjs for viewplans");
    res.send({ message: "Success! Retrieved plans", results: results });
  }
});

app.post("/createtask/:acronym", async (req, res) => {
  const acronym = req.body.acronym; //req is from axios
  const taskowner = req.body.taskowner;
  const taskname = req.body.taskname;
  const desc = req.body.desc;
  const taskplan = req.body.taskplan;
  const state = req.body.state;
  const creator = req.body.creator;

  console.log(taskowner);
  console.log(desc);
  console.log(tasknotes);
  //Date-Time
  const dayjs = require("dayjs");
  let today = dayjs();
  let datetime = today.format();
  console.log(datetime, "DATETIMEEE");

  //To get RNumber then TaskID
  let rnoone = await controller.rnoFunction(acronym);
  let rno2 = await controller.rnotwoFunction(acronym);
  console.log(rnoone[0].app_rnumber, "RNO 1");
  console.log(rno2.Task_name, "RNO 2");
  var rno = rnoone[0].app_rnumber + rno2.Task_name;
  console.log(rno);
  const taskid = acronym + "_" + rno;
  console.log(taskid);

  //Task Notes
  var tasknotes = creator + "_" + datetime + "_" + state;
  console.log(tasknotes);

  //Insert all fields
  let plancreate = await controller.createtaskFunction(taskname, taskowner, desc, taskplan, state, taskid, creator, tasknotes, acronym);
  if (plancreate == "1") {
    console.log(plancreate, "Main Message Successful creation");
    res.send({ message: "Successful Creation of a task!", results: plancreate });
  } else if (plancreate == "0") {
    res.send({ message: "Unsuccessful. Duplicate Data. Try Different task name", results: plancreate });
  } else {
    console.log("Error in querying for registering to database");
    res.send({ message: "Unsuccessful query", results: plancreate });
  }
});

// View all Users at Edit User
app.post("/viewtaskplans/:acronym", async (req, res) => {
  //****Retrieve plans list first****
  const acronym = req.body.acronym;
  // console.log(acronym, "received!!!!!");
  let results = await controller.viewtaskplansFunction(acronym);
  if (results.length > 0) {
    // console.log(results, "mainjs for viewtaskplans");
    res.send({ message: "Success! Retrieved plans", results: results });
  }
});

// View all Users at Edit User
app.post("/viewtasks/:acronym", async (req, res) => {
  //****Retrieve plans list first****
  const acronym = req.body.acronym;
  // console.log(acronym, "sending to viewtasks FUNCTIONN");
  let results = await controller.viewtasksFunction(acronym);
  if (res) {
    // console.log(results, "mainjs for view tasks");
    res.send({ message: "Success! Retrieved Tasks", results: results });
  }
});

//Change of Task States from Kanban Board
app.post("/edittask/:acronym", async (req, res) => {
  //Date-Time
  const dayjs = require("dayjs");
  let today = dayjs();
  let datetime = today.format();

  const acronym = req.body.acronym;
  const taskowner = req.body.user;
  const tasknames = req.body.taskname;
  const state = req.body.state;
  const myJSON = JSON.stringify(tasknames);
  const taskname = myJSON.replace("[", "").replace('"', "").replace("]", "").replace('"', "");
  const user = req.body.user;
  console.log(taskname, "MY TASKNAMENAMENAME");
  console.log(taskowner, "OWNERRRRR");
  console.log(state, "WODESTATES");

  //Task Notes
  const tasknotes = "Δ" + user + " at " + datetime + " Δ " + "changed the task to " + state + ".Δ";
  console.log(tasknotes, "MY TASKNOTESSSSSSS");
  let result = await controller.addcommentFunction(tasknotes, taskname, acronym);
  if (result == "0") {
    console.log("failed to add comment");
  } else if (result == "1") {
    console.log("Successful adding of comment");
  }

  let results = await controller.edittaskFunction(state, taskowner, taskname, acronym);
  if (results === true) {
    //   res.send(results);
    console.log("Results are TRUEEEEEEEEEEEEE");
    res.send({ message: "Successfully update of task!" });
  } else {
    console.log("Error1234");
    res.send({ message: "Error! in updating of task" });
  }
  if (state === "Done") {
    console.log("Taskname is DONEEE");
    var transport = nodemailer.createTransport({
      host: "smtp.mailtrap.io",
      port: 2525,
      auth: {
        user: "5e0c3ac92be7aa",
        pass: "f49bec11043956",
      },
    });

    let groupname = "%Project Lead%";
    let PLresults = await controller.PLFunction(groupname);
    console.log(PLresults);
    console.log(groupname);
    var projarray = [];
    for (let i = 0; i < PLresults.length; i++) {
      projarray.push(PLresults[i].email);
    }
    // send mail with defined transport object
    let info = await transport.sendMail({
      from: "CHAN0999@ntu.edu.sg", // sender address
      to: projarray, // list of receivers
      subject: taskname + " Completed", // Subject line
      text: user + " DONE " + taskname, // plain text body
      // html body
    });
  }
});

// //Nodemailer
// var transporter = nodemailer.createTransport({
//   service: "gmail",
//   auth: {
//     user: "youremail@gmail.com",
//     pass: "yourpassword",
//   },
// });

app.post("/edittaskpage/:acronym/:taskname", async (req, res) => {
  //****Retrieve particulars of user1 first****
  const taskname = req.body.taskname;
  const acronym = req.body.acronym;

  let results = await controller.fetchEditTaskFunction(taskname, acronym);
  if (res) {
    //response must be username and email
    // console.log(results, "main");
    //   res.send(results);
    res.send({ message: "Success! Retrieved particulars of the task", results: results });
  } else {
    console.log("Error");
    res.send({ message: "Error! in retrieving particulars of the task", results: results });
  }
});

app.post("/edittasks", async (req, res) => {
  //Date-Time
  const dayjs = require("dayjs");
  let today = dayjs();
  let datetime = today.format();
  console.log(datetime, "DATETIMEEE");
  const user = req.body.user;
  const taskowner = req.body.user;
  const acronym = req.body.acronym;
  const taskplan = req.body.taskplan;
  const desc = req.body.desc;
  const taskname = req.body.taskname;
  const notes = req.body.tasknotes;
  console.log("MY DESCCCCCCCCC", desc);
  const tasknotes = "Δ" + datetime + "Δ " + user + " Commented: Δ" + req.body.tasknotes + "Δ"; //req is from axios
  if ((notes == "", desc == "")) {
    res.send({ message: "Please fill in one of the blanks before submitting." });
  } else if (notes !== "") {
    let results = await controller.addcommentFunction(tasknotes, taskname, acronym);
    if (results == "1") {
      //if tasknotes successfully added,
      if (desc !== "") {
        //if desc not blank, UPDATE
        let result = await controller.edittasksFunction(desc, taskowner, taskplan, taskname, acronym);
        if (result == "0") {
          // console.log(result, "main");
          res.send({ message: "Failed to change desc details!", results: result });
        } else if (results == "1") {
          // console.log(results, "main");
          res.send({ message: "Successfully changed desc details!", results: result });
        } else {
          console.log("There is a problem");
        }
      } else if (desc == "") {
        res.send({ message: "Successfully changed desc details!", results: results });
      }
    }
  } else if (notes == "") {
    let result = await controller.edittasksFunction(desc, taskowner, taskplan, taskname, acronym);
    if (result == "0") {
      // console.log(result, "main");
      res.send({ message: "Failed to change desc details!", results: result });
    } else if (result == "1") {
      // console.log(result, "main");
      res.send({ message: "Successfully changed desc details!", results: result });
    } else {
      console.log("There is a problem");
    }
  } else {
    console.log("concat notes failed!");
    res.send({ message: "Failed to add comment details!", results: results });
  }
});

app.post("/apppermits", async (req, res) => {
  //****Retrieve plans list first****
  const acronym = req.body.acronym;
  // console.log(acronym);
  let viewappresults = await controller.viewapppermitsFunction(acronym);
  if (res) {
    // console.log(results, "mainjs for app permits");
    res.send({ message: "Success! Retrieved app permits", results: viewappresults });
  }
});

//retrieving admins
app.post("/getuserpermits", async (req, res) => {
  const username = req.body.userid;
  console.log(username, "USERNAME FOR PERMIT CHECKS");
  let userpermresults = await controller.getuserpermitsFunction(username);
  console.log(userpermresults, "RESULTS");
  if (userpermresults.length > 0) {
    if (userpermresults.includes(",") == true) {
      const checking = userpermresults.replaceAll(",", "");
      const checkPL = checking.includes("Project Lead"); //output true or false
      const checkPM = checking.includes("Project Manager");
      const checkTM = checking.includes("Team Member");
      console.log(checking, "CHECKINGSSSS");
      console.log(checkPL);
      console.log(checkPM);
      console.log(checkTM);
      res.send({ message: "Success! ", userpermresults: userpermresults, PL: checkPL, PM: checkPM, TM: checkTM, checks: true });
    } else {
      //if single value of role
      const checking = userpermresults;
      const checkPL = checking.includes("Project Lead"); //output true or false
      const checkPM = checking.includes("Project Manager");
      const checkTM = checking.includes("Team Member");
      console.log(checking, "CHECKINGSSSS WOOOO");
      console.log(checkPL);
      console.log(checkPM);
      console.log(checkTM);
      res.send({ message: "Success!", userpermresults: userpermresults, PL: checkPL, PM: checkPM, TM: checkTM, checks: true });
    }
  } else {
    res.send({ message: "Failure!", userpermresults: userpermresults, checks: false });
  }
});

app.post("/viewplan/:acronym/:mvpname", async (req, res) => {
  //****Retrieve plans list first****
  const acronym = req.body.acronym;
  const mvpname = req.body.mvpname;
  console.log(acronym);
  let results = await controller.viewplanFunction(acronym, mvpname);
  if (res) {
    // console.log(results, "mainjs for viewplans");
    res.send({ message: "Success! Retrieved MY PLAN", results: results });
  }
});

app.post("/editplan/:acronym/:mvpname", async (req, res) => {
  const acronym = req.body.acronym;
  const mvpname = req.body.mvpname;
  const startdate = req.body.startdate;
  const enddate = req.body.enddate;
  const desc = req.body.desc;
  console.log(desc);
  console.log(startdate);
  console.log(enddate);
  let planedit = await controller.editplanFunction(desc, startdate, enddate, mvpname, acronym);
  if (planedit == "1") {
    console.log(planedit, "Main Message Successful creation");
    res.send({ message: "Successful edit of Plan!", results: planedit });
  } else if (planedit == "0") {
    res.send({ message: "Unsuccessful Edit of Plan.", results: planedit });
  } else {
    console.log("Error in querying for registering to database");
    res.send({ message: "Unsuccessful query", results: planedit });
  }
});

app.get("/projectlead", async (req, res) => {
  userid = req.session.user;
  let groupname = "%Project Lead%";
  console.log(userid, "USERNAME FOR ADMIN CHECKS");
  let results = await controller.checkgroupFunction(userid, groupname);
  if (results == 1) {
    res.send({ message: "Success! User is a PL", results: userid, plead: true });
  } else {
    res.send({ message: "Failure not a PL", results: userid, plead: false });
  }
});

app.get("/projectmanager", async (req, res) => {
  userid = req.session.user;
  let groupname = "%Project Manager%";
  console.log(userid, "USERNAME FOR ADMIN CHECKS");
  let results = await controller.checkgroupFunction(userid, groupname);
  if (results == 1) {
    res.send({ message: "Success! User is a PM", results: userid, PM: true });
  } else if (results == 0) {
    res.send({ message: "Failure not a PM", results: results, PM: false });
  }
});

app.get("/teammember", async (req, res) => {
  userid = req.session.user;
  let groupname = "%Team Member%";
  console.log(userid, "USERNAME FOR CHECKS");
  let results = await controller.checkgroupFunction(userid, groupname);
  if (results == 1) {
    res.send({ message: "Success! User is a TM", results: userid, TM: true });
  } else {
    res.send({ message: "Failure not a TM", results: userid, TM: false });
  }
});

//*******PART 1 **********
app.post("/api/:App_Acronym/task/create", async (req, res) => {
  const acronym = req.params.App_Acronym;
  const username = req.body.Username;
  const password = req.body.Password;
  const Task_name = req.body.Task_name;
  const desc = req.body.Task_description;
  let taskplan = req.body.Task_plan;
  const state = "OPEN";
  const creator = req.body.Username;
  let valid_body = true;

  const items = ["Username", "Password", "Task_name"];
  for (index in items) {
    if (req.body.hasOwnProperty(items[index]) !== true) {
      valid_body = false;
    }
  }

  if (valid_body == true) {
    //1. For Invalid Body
    if (username.length <= 0) {
      valid_body = false;
    }
    if (password.length <= 0) {
      valid_body = false;
    }
    if (Task_name.length <= 0) {
      valid_body = false;
    }
  }

  if (valid_body == false) {
    return res.status(400).send({ message: "Invalid Body" });
  } else {
    //1. For Invalid Login
    let result = await controller.checkpwFunction(username);
    if (result == "0") {
      //no such user exists
      console.log("Invalid Authentication!");
      return res.status(401).send({ message: "Invalid Authentication. Try Again.", result: result });
    } else {
      hashed = result[0].password;
      console.log(hashed, "hashedpw");
      bcrypt.compare(password, hashed, function (err, result) {
        if (result == "1") {
          console.log("PW Matched");
          // res.send({ message: "Login Successful!", result: "Success!" });
          const login = true;
        } else if (result == "0") {
          console.log("Invalid Authentication!");
          return res.status(401).send({ message: "Invalid Authentication. Try Again.", result: "Log in failed" });
        } else {
          console.log("Error in querying for registering to database");
          return res.status(401).send({ message: "Unsuccessful query", result: "Error in querying to database" });
        }
      });
    }
  }

  // App Acro check it exists
  let acroresult = await controller.fetchacroFunction(acronym);
  if (acroresult.length > 0) {
    console.log("APP PERMS CREATE MEEP", acroresult[0].app_permit_create);
    var apppermscreate = "%" + acroresult[0].app_permit_create + "%";
    // res.send(results);
    // res.send({ message: "Success! acronym is found.", results: acroresult });
  } else {
    console.log("Error");
    return res.status(404).send({ message: "Error! Acronym cannot be found.", results: acroresult });
  }

  console.log(username);
  let results = await controller.checkgroupsFunction(username, apppermscreate);
  if (results == 1) {
    // res.send({ message: "Success! User is permitted to create apps", results: username, permscreate: true });
    var permscreate = true;
    console.log("Success! User is permitted to create apps");
  } else if (results == 0) {
    return res.status(403).send({ message: "Failure, user is not permitted to create apps", permscreate: false });
  }

  const taskname = Task_name;
  const taskowner = username;
  //Date-Time
  const dayjs = require("dayjs");
  let today = dayjs();
  let datetime = today.format();
  console.log(datetime, "DATETIMEEE");

  //To get RNumber then TaskID
  let rnoone = await controller.rnoFunction(acronym);
  let rno2 = await controller.rnotwoFunction(acronym);
  console.log(rnoone[0].app_rnumber, "RNO 1");
  console.log(rno2.Task_name, "RNO 2");
  var rno = rnoone[0].app_rnumber + rno2.Task_name;
  console.log(rno);
  const taskid = acronym + "_" + rno;
  console.log(taskid);

  //Task Notes
  var tasknotes = creator + "_" + datetime + "_" + state;
  console.log(tasknotes);

  if (taskplan !== "" && req.body.hasOwnProperty("Task_plan") == true) {
    // if it has something, check it exists in sql e.g "got_thing"
    let viewtaskplans = await controller.viewtaskplanstwoFunction(acronym, taskplan);
    if (viewtaskplans.length > 0) {
      console.log("Success! taskplan exists");
      // res.send({ message: "Success! taskplan exists", results: viewtaskplans });
    } else {
      return res.status(400).send({ message: "Failure, task plan does not exist" });
    }
  }
  if (req.body.hasOwnProperty("Task_plan") == false) {
    taskplan = "";
  }
  //Insert all fields
  let plancreate = await controller.createtaskFunction(taskname, taskowner, desc, taskplan, state, taskid, creator, tasknotes, acronym);
  if (plancreate == "1") {
    console.log(plancreate, "Main Message Successful creation");
    return res.send({ message: "Successful Creation of a task!", results: taskid });
  } else if (plancreate == "0") {
    return res.status(400).send({ message: "Unsuccessful. Duplicate Data. Try Different task name", results: plancreate });
  } else {
    console.log("Error in querying for registering to database");
    return res.status(400).send({ message: "Unsuccessful query", results: plancreate });
  }
});

//******PART 2 **********
app.get("/api/:App_Acronym/taskbystate", async (req, res) => {
  const acronym = req.params.App_Acronym;
  const username = req.body.Username;
  const password = req.body.Password;
  let taskstate = req.query.task_state;
  let valid_body = true;

  const items = ["Username", "Password"];
  for (index in items) {
    if (req.body.hasOwnProperty(items[index]) !== true) {
      valid_body = false;
    }
  }

  if (valid_body == false) {
    return res.status(400).send({ message: "Invalid Body" });
  }

  const login = true;
  //1. For Invalid Body
  if (username.length <= 0) {
    console.log(username);
    return res.status(401).send({ message: "Username must be filled." });
  } else if (password.length <= 0) {
    console.log(password);
    return res.status(401).send({ message: "Password must be filled.", password: password });
  } else {
    //1. For Invalid Login
    let data_result = await controller.checkpwFunction_ASS3(username);
    if (data_result[0] == false) {
      //no such user exists
      console.log("Invalid Authentication!");
      return res.status(401).send({ message: "Invalid Authentication. Try Again.", result: data_result });
    } else {
      hashed = data_result[1][0].password;
      bcrypt.compare(password, hashed, async function (err, bcrypt_result) {
        if (bcrypt_result == true) {
          let acroresult = await controller.fetchacroFunction(acronym);
          if (acroresult.length > 0) {
            console.log("aPP ACRO EXISTS");
          } else {
            console.log("Error");
            return res.status(404).send({ message: "Error! Acronym cannot be found.", results: acroresult });
          }

          //Check State exists
          console.log("TASK STATE UPPERSCASES", taskstate.toUpperCase());
          taskstate = taskstate.toUpperCase();
          if (taskstate == "OPEN" || taskstate == "TODO" || taskstate == "DOING" || taskstate == "DONE" || taskstate == "CLOSED") {
            //Retrieving Tasks
            let taskbystate = await controller.viewtaskbystateFunction(acronym, taskstate);
            if (taskbystate == false) {
              return res.send({ message: "No Task in that state", results: taskbystate });
            } else {
              // console.log(results, "mainjs for view tasks");
              return res.send({ message: "Success! Retrieved Task by State", results: taskbystate });
            }
          } else {
            return res.status(400).send({ message: "Task State is Invalid." });
          }
        } else if (bcrypt_result == false) {
          console.log("Invalid Authentication!");
          return res.status(401).send({ message: "Invalid Authentication. Try Again.", result: "Log in failed" });
        } else {
          console.log("Error in querying for registering to database");
          return res.status(401).send({ message: "Unsuccessful query", result: "Error in querying to database" });
        }
      });
    }
  }

  // App Acro check it exists
  // let acroresult = await controller.fetchacroFunction(acronym);
  // if (acroresult.length > 0) {
  //   console.log("aPP ACRO EXISTS");
  // } else {
  //   console.log("Error");
  //   return res.status(404).send({ message: "Error! Acronym cannot be found.", results: acroresult });
  // }

  // //Check State exists
  // console.log("TASK STATE UPPERSCASES", taskstate.toUpperCase());
  // taskstate = taskstate.toUpperCase();
  // if (taskstate == "OPEN" || taskstate == "TODO" || taskstate == "DOING" || taskstate == "DONE" || taskstate == "CLOSED") {
  //   //Retrieving Tasks
  //   let taskbystate = await controller.viewtaskbystateFunction(acronym, taskstate);
  //   if (taskbystate == false) {
  //     return res.send({ message: "No Task in that state", results: taskbystate });
  //   } else {
  //     // console.log(results, "mainjs for view tasks");
  //     return res.send({ message: "Success! Retrieved Task by State", results: taskbystate });
  //   }
  // } else {
  //   return res.status(400).send({ message: "Task State is Invalid." });
  // }
});

// ************PART 3****************
// Promote task from doing to done
app.post("/api/:App_Acronym/task/:Task_id/promotedoing", async (req, res) => {
  const acronym = req.params.App_Acronym;
  const taskid = req.params.Task_id;
  const username = req.body.Username;
  const password = req.body.Password;
  let valid_body = true;

  const items = ["Username", "Password"];
  for (index in items) {
    if (req.body.hasOwnProperty(items[index]) !== true) {
      valid_body = false;
    }
  }

  if (valid_body == false) {
    return res.status(400).send({ message: "Invalid Body" });
  }

  console.log(username);
  if (username.length <= 0) {
    console.log(username);
    return res.status(401).send({ message: "Username must be filled." });
  } else if (password.length <= 0) {
    console.log(password);
    return res.status(401).send({ message: "Password must be filled.", password: password });
  } else if (acronym.length <= 0) {
    return res.status(400).send({ message: "Task Acronym cannot be blank. Please give task an acronym." });
  } else if (taskid.length <= 0) {
    return res.status(400).send({ message: "Task ID cannot be blank. Please give a task ID." });
  } else {
    //1. For Invalid Login
    let result = await controller.checkpwFunction(username);
    if (result == "0") {
      //no such user exists
      console.log("Invalid Authentication!");
      return res.status(401).send({ message: "Invalid Authentication. Try Again." });
    } else {
      hashed = result[0].password;
      console.log(hashed, "hashedpw");
      bcrypt.compare(password, hashed, async function (err, result) {
        if (result == "1") {
          console.log("PW Matched");
          // res.send({ message: "Login Successful!", result: "Success!" });
          let acroresult = await controller.fetchacroFunction(acronym);
          if (acroresult.length > 0) {
            console.log("APP PERMS doing MEEP", acroresult[0].app_permit_doing);
            var apppermsdoing = "%" + acroresult[0].app_permit_doing + "%";
          } else {
            console.log("Error");
            return res.status(404).send({ message: "Error! Acronym cannot be found." });
          }

          // Check user perms
          console.log(username);
          let results = await controller.checkgroupsFunction(username, apppermsdoing);
          if (results == 1) {
            // res.send({ message: "Success! User is permitted to create apps", results: username, permscreate: true });
            console.log("Success! User is permitted to update state of task from doing to done.");
          } else if (results == 0) {
            return res.status(403).send({ message: "Failure, user is not permitted to update task from doing to done." });
          }

          //Check if Task ID exists
          console.log("MY TASKID YOHHHHhh", taskid);
          let idresult = await controller.fetchidFunction(acronym, taskid);
          if (idresult.length > 0) {
            console.log("ID EXISTS", idresult[0].Task_state);
            var taskidstate = idresult[0].Task_state;
            var taskname = idresult[0].Task_name;
          } else {
            console.log("Error");
            return res.status(404).send({ message: "Error! TASK ID cannot be found." });
          }

          //Update if it is in Doing State
          if (taskidstate !== "DOING") {
            return res.status(400).send({ message: "Task is not in Doing State" });
          } else {
            var taskstate = "DONE";
            let update = await controller.updatedoingtodoneFunction(taskstate, acronym, taskid);
            if (update == "0") {
              // console.log(result, "main");
              return res.status(400).send({ message: "Failed to update State from Doing to Done." });
            } else if (results == "1") {
              // console.log(results, "main");
              console.log("Successfully updated State from Doing to Done!");

              var transport = nodemailer.createTransport({
                host: "smtp.mailtrap.io",
                port: 2525,
                auth: {
                  user: "5e0c3ac92be7aa",
                  pass: "f49bec11043956",
                },
              });

              let groupname = apppermsdoing;
              let PLresults = await controller.PLFunction(groupname);
              console.log("MYPLRESULTS PLPLPEEP", PLresults);
              console.log("my GROUPNAMEEEEE", groupname);
              var projarray = [];
              for (let i = 0; i < PLresults.length; i++) {
                projarray.push(PLresults[i].email);
              }
              // send mail with defined transport object
              let info = transport.sendMail({
                from: "CHAN0999@ntu.edu.sg", // sender address
                to: projarray, // list of receivers
                subject: taskname + " Completed", // Subject line
                text: username + " DONE " + taskname, // plain text body
              });
              return res.send({ message: "Successful" });
            }
          }
        } else if (result == "0") {
          console.log("Invalid Authentication!");
          return res.status(401).send({ message: "Invalid Authentication. Try Again.", result: "Log in failed" });
        } else {
          console.log("Error in querying for registering to database");
          return res.status(401).send({ message: "Unsuccessful query", result: "Error in querying to database" });
        }
      });
    }
  }

  // App Acro check it exists
  // let acroresult = await controller.fetchacroFunction(acronym);
  // if (acroresult.length > 0) {
  //   console.log("APP PERMS doing MEEP", acroresult[0].app_permit_doing);
  //   var apppermsdoing = "%" + acroresult[0].app_permit_doing + "%";
  //   // res.send(results);
  //   // res.send({ message: "Success! acronym is found.", results: acroresult });
  // } else {
  //   console.log("Error");
  //   return res.status(404).send({ message: "Error! Acronym cannot be found.", results: acroresult });
  // }

  // // Check user perms
  // console.log(username);
  // let results = await controller.checkgroupsFunction(username, apppermsdoing);
  // if (results == 1) {
  //   // res.send({ message: "Success! User is permitted to create apps", results: username, permscreate: true });
  //   console.log("Success! User is permitted to update state of task from doing to done.");
  // } else if (results == 0) {
  //   return res.status(403).send({ message: "Failure, user is not permitted to update task from doing to done." });
  // }

  // //Check if Task ID exists
  // console.log("MY TASKID YOHHHHhh", taskid);
  // let idresult = await controller.fetchidFunction(acronym, taskid);
  // if (idresult.length > 0) {
  //   console.log("ID EXISTS", idresult[0].Task_state);
  //   var taskidstate = idresult[0].Task_state;
  //   var taskname = idresult[0].Task_name;
  // } else {
  //   console.log("Error");
  //   return res.status(404).send({ message: "Error! TASK ID cannot be found." });
  // }

  // //Update if it is in Doing State
  // if (taskidstate !== "DOING") {
  //   return res.status(400).send({ message: "Task is not in Doing State" });
  // } else {
  //   var taskstate = "DONE";
  //   let update = await controller.updatedoingtodoneFunction(taskstate, acronym, taskid);
  //   if (update == "0") {
  //     // console.log(result, "main");
  //     return res.status(400).send({ message: "Failed to update State from Doing to Done." });
  //   } else if (results == "1") {
  //     // console.log(results, "main");
  //     console.log("Successfully updated State from Doing to Done!");

  //     var transport = nodemailer.createTransport({
  //       host: "smtp.mailtrap.io",
  //       port: 2525,
  //       auth: {
  //         user: "5e0c3ac92be7aa",
  //         pass: "f49bec11043956",
  //       },
  //     });

  //     let groupname = apppermsdoing;
  //     let PLresults = await controller.PLFunction(groupname);
  //     console.log("MYPLRESULTS PLPLPEEP", PLresults);
  //     console.log("my GROUPNAMEEEEE", groupname);
  //     var projarray = [];
  //     for (let i = 0; i < PLresults.length; i++) {
  //       projarray.push(PLresults[i].email);
  //     }
  //     // send mail with defined transport object
  //     let info = await transport.sendMail({
  //       from: "CHAN0999@ntu.edu.sg", // sender address
  //       to: projarray, // list of receivers
  //       subject: taskname + " Completed", // Subject line
  //       text: username + " DONE " + taskname, // plain text body
  //     });
  //   }
  // }
});

//No permissions
// let viewappresults = await controller.viewapppermitsFunction(acronym);
// if (viewappresults.length>0) {
//   var apppermitcreate = viewappresults[0].app_permit_create;
//   var apppermitopen = viewappresults[0].app_permit_open;
//   var apppermittodo = viewappresults[0].app_permit_todolist;
//   var apppermitdoing= viewappresults[0].app_permit_doing;
//   var apppermitdone = viewappresults[0].app_permit_done;
//   // res.send({ message: "Success! Retrieved app permits"});
// } else {
//   res.send({ message: "Error in retrieving app permit data", results: viewappresults});
// }

//For checkgroup Function
// let userpermresults = await controller.getuserpermitsFunction(username);
// console.log(userpermresults, "RESULTS"); //consists of the belongsto roles the username has
// if (userpermresults.length > 0) {
//     if (userpermresults.includes(apppermitcreate)) {
//       const permscreate = true;
//       console.log("permscreate true");
//     }
//       if (userpermresults.includes(apppermitopen)) {
//         console.log("permsopen true");
//         const permsopen = true;
//       }
//     if (userpermresults.includes(apppermittodo)) {
//       const permstodo = true;
//       console.log("permstodo true");
//     }
//     if (userpermresults.includes(apppermitdoing)) {
//       const permsdoing = true;
//       console.log("permsdoing true");
//     }
//     if (userpermresults.includes(apppermitdone)) {
//       const permsdone = true;
//       console.log("permsdone true");
//     }
//     res.send({ message: "Success! for userperm results", userpermresults: userpermresults });
// } else {
//   res.send({ message: "Failure!", userpermresults: userpermresults});
// }

//No permissions
// let viewappresults = await controller.viewapppermitsFunction(acronym);
// if (viewappresults.length>0) {
//   var apppermitcreate = viewappresults[0].app_permit_create;
//   var apppermitopen = viewappresults[0].app_permit_open;
//   var apppermittodo = viewappresults[0].app_permit_todolist;
//   var apppermitdoing= viewappresults[0].app_permit_doing;
//   var apppermitdone = viewappresults[0].app_permit_done;
//   // res.send({ message: "Success! Retrieved app permits"});
// } else {
//   res.send({ message: "Error in retrieving app permit data", results: viewappresults});
// }

// if (userpermresults.length > 0) {
//   if (userpermresults.includes(apppermitcreate)) {
//     const permscreate = true;
//     console.log("permscreate true");
//   }
//     if (userpermresults.includes(apppermitopen)) {
//       console.log("permsopen true");
//       const permsopen = true;
//     }
//   if (userpermresults.includes(apppermittodo)) {
//     const permstodo = true;
//     console.log("permstodo true");
//   }
//   if (userpermresults.includes(apppermitdoing)) {
//     const permsdoing = true;
//     console.log("permsdoing true");
//   }
//   if (userpermresults.includes(apppermitdone)) {
//     const permsdone = true;
//     console.log("permsdone true");
//   }
//   res.send({ message: "Success! for userperm results", userpermresults: userpermresults });
