// const { resolve } = require("path")
// const mysql = require("mysql2");
// const app = express();

// const pool = mysql.createPool({
//   connectionLimit: 10,
//   host: process.env.HOST,
//   port: process.env.PORT,
//   user: process.env.USER,
//   password: process.env.PASSWORD,
//   database: process.env.DATABASE,
// });

console.log("HIIIIIII");
// const connectToDatabase = () => {
//   const dummyPromise = new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve();
//       app.listen(port, () => {
//         console.log("Express server listening on port" + port);
//       });
//     }, 1000);
//   });

//   return dummyPromise;
// };
// export default connectToDatabase;
