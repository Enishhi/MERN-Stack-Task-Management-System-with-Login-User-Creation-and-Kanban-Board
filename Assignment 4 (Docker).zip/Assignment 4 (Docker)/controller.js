const con = require("./mysqlcon.js");
const bcrypt = require("bcrypt");
const { resourceLimits } = require("worker_threads");

// con.query("SELECT 1 + 1 AS solution", function (error, result, fields) {
//   if (error) throw error;
//   console.log("The solution is: ", result[0].solution);
// });

//For checkgroup Function
exports.checkgroupFunction = (userid, groupname) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `accounts` WHERE `username` = ? and belongsto LIKE ?", [userid, groupname], (error, result) => {
      console.log(result, "SQL RESULTS"); //queries to take all accounts that has admin in belongsto column
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error, False");
        resolve("0");
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("controller admin", result[0]); //outputs the usernames that are admin
        console.log("Retrieval Successful, Admin True");
        resolve("1");
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful, perhaps there is no admins", result[0]);
        resolve("0");
      }
    });
  });
};

exports.checkpwFunction = (username) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `accounts` WHERE `username` = ?", [username], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error with query");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("controller for pw", result[0]);
        console.log("Successful");
        resolve(result);
      } else {
        console.log(result);
        console.log("Error in username");
        resolve("0");
      }
    });
  });
};

exports.checkpwFunction_ASS3 = (username) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `accounts` WHERE `username` = ?", [username], (error, result) => {
      // console.log("BABA: ", username);
      // console.log("BABA: ", result);
      // console.log("BABA: ", error);
      if (error) {
        resolve(error);
      } else {
        if (result.length > 0) {
          // user exists
          resolve([true, result]);
        } else {
          // user does not exists
          resolve([false, result]);
        }
      }
    });
  });
};

// //For Login Function
// exports.loginFunction = (username) => {
//   return new Promise((resolve, reject) => {
//     con.query("SELECT * FROM `accounts` WHERE `username` = ? ", [username], (error, result) => {
//       console.log(result);
//       if (error) {
//         //Send to console that there is an error with database
//         console.log(error,"ERROR");
//         console.log("Error Logging In");
//         resolve(error);
//       } //if it is sending error, it won't proceed on
//       if (result.length > 0) {
//         // bcrypt.compare(password, result[0].password, (error, response) => {
//         // if (response) {
//         console.log("controller", result[0]);
//         console.log("Login Successful");
//         resolve("1");
//       } else {
//         // res.send({message:"Wrong username/Password combination!"});
//         console.log("Error");
//       }
//     });
//   });
// };

exports.createuserFunction = (username, hash, email) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `accounts` WHERE `username` = ?", [username], (error, result) => {
      if (result.length > 0) {
        //There is duplicate, send the message
        console.log("Duplicate User");
        resolve("0");
      } else {
        con.query("INSERT INTO accounts (username, password, email) VALUES (?, ?, ?)", [username, hash, email], (error, result) => {
          //if error throw error
          if (result) {
            //There is duplicate, send the message
            console.log("Successfully regsitered to database");
            console.log(result, "controller insert");
            resolve("1");
          }
          if (error) {
            //Send to console that there is an error with database
            console.log(error);
            console.log("Error in creating user, could be duplicates");
            resolve(error);
          }
          //if it is sending error, it won't proceed on
        });
      }
    });
  });
};

// Edit Profile
// exports.editprofileFunction = (username, newpassword, newemail) => {
//   return new Promise((resolve, reject) => {
//     con.query("UPDATE accounts SET password = ?, email = ? WHERE username = ?", [newpassword, newemail, username], (error, result) => {
//       console.log(result);
//       if (error) {
//         //Send to console that there is an error with database
//         console.log(error);
//         console.log("Error registering into database");
//         reject(error);
//         return error;
//       } //if it is sending error, it won't proceed on
//       if (result.length > 0) {
//         // bcrypt.compare(password, result[0].password, (error, response) => {
//         // if (response) {
//         console.log("controller", result[0]);
//         console.log("Successfully updated");
//         resolve(result);
//       } else {
//         // res.send({message:"Wrong username/Password combination!"});
//         console.log("Username not found");
//       }
//     });
//   });
// };

exports.editprofileFunction = (username, hash, newemail) => {
  return new Promise((resolve, reject) => {
    let conquery = "UPDATE accounts SET password = ?, email = ? WHERE username = ?";
    let editdata = [hash, newemail, username];
    console.log(newemail, "new email");
    console.log(hash, "new password");
    if (!newemail) {
      //if email is not changed
      conquery = "UPDATE accounts SET password = ? WHERE username = ?";
      editdata = [hash, username];
      console.log("no new email");
    } else if (!hash) {
      //if password is not changed, still same old
      conquery = "UPDATE accounts SET email = ? WHERE username = ?";
      editdata = [newemail, username];
      console.log("no new password");
    }

    con.query(conquery, editdata, (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error registering into database");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successfully updated for user");
        resolve(result);
      }
    });
  });
};

//For Login Function
// exports.refreshprofileFunction = (username) => {
//   return new Promise((resolve, reject) => {
//     con.query("SELECT email FROM `accounts` WHERE `username` = ?", [username], (error, result) => {
//       console.log(result);
//       if (error) {
//         //Send to console that there is an error with database
//         console.log(error);
//         console.log("Error Logging In");
//         reject(error);
//         return error;
//       } //if it is sending error, it won't proceed on
//       if (result.length > 0) {
//         // bcrypt.compare(password, result[0].password, (error, response) => {
//         // if (response) {
//         console.log("controller", result[0]);
//         console.log("Login Successful");
//         resolve(result);
//       } else {
//         // res.send({message:"Wrong username/Password combination!"});
//         console.log("Wrong username/Password combination!");
//       }
//     });
//   });
// };

// Edit users
//View particulars first
exports.fetchEditUserFunction = (user) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `accounts` WHERE `username` = ?", [user], (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for User");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of User");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Wrong username!");
      }
    });
  });
};

exports.viewallusersFunction = () => {
  return new Promise((resolve, reject) => {
    con.query("SELECT username, email, status, belongsto FROM `accounts`", (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of users");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of Users");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful retrieval of users");
      }
    });
  });
};

exports.edituserFunction = (user, hash, newemail) => {
  return new Promise((resolve, reject) => {
    let conquery = "UPDATE accounts SET password = ?, email = ? WHERE username = ?";
    let editdata = [hash, newemail, user];
    console.log(newemail, "new email");
    console.log(hash, "new password");
    if (!newemail) {
      //if email is not changed
      conquery = "UPDATE accounts SET password = ? WHERE username = ?";
      editdata = [hash, user];
      console.log("no new email");
    } else if (!hash) {
      //if password is not changed, still same old
      conquery = "UPDATE accounts SET email = ? WHERE username = ?";
      editdata = [newemail, user];
      console.log("no new password");
    }
    con.query(conquery, editdata, (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error registering into database");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successfully updated for user");
        resolve(result);
      }
    });
  });
};

exports.viewusergroupFunction = () => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `usergroup`", (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for User Groups");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of User Groups");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful retrieval of user groups");
      }
    });
  });
};

exports.viewuserrolesFunction = () => {
  return new Promise((resolve, reject) => {
    con.query("SELECT role FROM `usergroup`", (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for User Groups");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("controller", result);
        console.log("Successful Retrieval of roles only");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful retrieval of user groups");
      }
    });
  });
};

//For Register Function
exports.createusergroupFunction = (role, groupstatus) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `usergroup` WHERE `role` = ?", [role], (error, result) => {
      if (result.length > 0) {
        //There is duplicate, send the message
        console.log("Duplicate Usergroup");
        resolve("0");
      } else {
        con.query("INSERT INTO usergroup (role, status) VALUES (?,?)", [role, groupstatus], (error, result) => {
          //if error throw error
          if (result) {
            //There is duplicate, send the message
            console.log("Successfully regsitered to database");
            console.log(result, "controller insert");
            resolve("1");
          }
          if (error) {
            //Send to console that there is an error with database
            console.log(error);
            console.log("Error in creating user, could be duplicates");
            resolve(error);
          }
        });
      }
    });
  });
};

exports.groupscheckboxFunction = (checkboxesID) => {
  return new Promise((resolve, reject) => {
    con.query("UPDATE usergroup SET status = (CASE status WHEN 1 THEN 0 ELSE 1 END) WHERE role = ?", checkboxesID, (error, result) => {
      //if error throw error
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error in enable/disable user group");
        return error;
      } //if it is sending error, it won't proceed on
      else {
        console.log("You have successfully updated a user group!");
        resolve(result);
      }
    });
  });
};

exports.userscheckboxFunction = (checkboxesuser) => {
  return new Promise((resolve, reject) => {
    con.query("UPDATE accounts SET status = (CASE status WHEN 1 THEN 0 ELSE 1 END) WHERE username = ?", [checkboxesuser], (error, result) => {
      //if error throw error
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error in enable/disable users");
        return error;
      } //if it is sending error, it won't proceed on
      else {
        console.log("You have successfully updated users");
        resolve(result);
      }
    });
  });
};
//Get user's ticked checked boxes in Edit User
exports.usergetcheckedboxesFunction = () => {
  return new Promise((resolve, reject) => {
    con.query("SELECT belongsto FROM `accounts`", (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for belongsto");
        reject(error);
        return error;
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("Successful Retrieval of User Groups");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful retrieval of user groups");
      }
    });
  });
};

exports.editusercheckboxFunction = (checkedrole, user) => {
  return new Promise((resolve, reject) => {
    con.query("UPDATE accounts SET belongsto=? WHERE (username = ?)", [checkedrole, user], (error, result) => {
      //if error throw error
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error in enable/disable");
        return error;
      } //if it is sending error, it won't proceed on
      else {
        console.log("You have successfully updated a user group!");
        console.log(result);
        resolve(result);
      }
    });
  });
};

exports.createappFunction = (acronym, desc, rno, startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `application` WHERE `app_acronym` = ?", [acronym], (error, result) => {
      if (result.length > 0) {
        //There is duplicate of app, send the message
        console.log("Duplicate Application Name");
        resolve("0");
      } else {
        con.query("INSERT INTO application (app_acronym,app_description,app_rnumber,app_startdate,app_enddate,app_permit_create,app_permit_open,app_permit_todolist,app_permit_doing,app_permit_done) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [acronym, desc, rno, startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone], (error, result) => {
          //if error throw error
          if (result) {
            //There is duplicate, send the message
            console.log("Successfully regsitered to database");
            console.log(result, "controller insert");
            resolve("1");
          }
          if (error) {
            //Send to console that there is an error with database
            console.log(error);
            console.log("Error in creating user, could be duplicates");
            resolve(error);
          }
          //if it is sending error, it won't proceed on
        });
      }
    });
  });
};

// exports.apppermitsFunction = (acronym, permitopen, permittodo, permitdoing, permitdone) => {
//   return new Promise((resolve, reject) => {
//     con.query("SELECT * FROM `application` WHERE `app_acronym` = ?", [acronym], (error, result) => {
//       if (result.length > 0) {
//         //There is duplicate of app, send the message
//         console.log("Duplicate Application Name");
//         resolve("0");
//       } else {
//         con.query("INSERT INTO application (app_acronym,app_permit_open,app_permit_todolist,app_permit_doing,app_permit_done) VALUES (?, ?, ?, ?, ?)", [acronym, permitopen, permittodo, permitdoing, permitdone], (error, result) => {
//           //if error throw error
//           if (result) {
//             //There is duplicate, send the message
//             console.log("Successfully regsitered to database");
//             console.log(result, "controller insert");
//             resolve("1");
//           }
//           if (error) {
//             //Send to console that there is an error with database
//             console.log(error);
//             console.log("Error in creating user, could be duplicates");
//             resolve(error);
//           }
//           //if it is sending error, it won't proceed on
//         });
//       }
//     });
//   });
// };

exports.viewappsFunction = () => {
  return new Promise((resolve, reject) => {
    con.query('SELECT app_acronym, app_description, app_rnumber, DATE_FORMAT(app_startdate, "%Y-%m-%d") AS app_startdate, DATE_FORMAT(app_enddate, "%Y-%m-%d") AS app_enddate FROM `application`', (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of applications");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of Users");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful retrieval of users");
      }
    });
  });
};

exports.fetchEditAppFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    sql_query = 'SELECT app_acronym, app_description, app_rnumber, DATE_FORMAT(app_enddate, "%Y-%m-%d") AS app_enddate, DATE_FORMAT(app_startdate, "%Y-%m-%d") AS app_startdate, app_permit_create,app_permit_open, app_permit_todolist, app_permit_doing, app_permit_done FROM `application` WHERE `app_acronym` = ?';

    con.query(sql_query, [acronym], (error, result) => {
      console.log(result);
      if (error) {
        console.log(error);
        console.log("Error Looking for App");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("Successful Retrieval of Application Requested");
        resolve(result);
      } else {
        console.log("Application not found");
      }
    });
  });
};

exports.editappsFunction = (desc, startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym) => {
  return new Promise((resolve, reject) => {
    let conquery = "UPDATE application SET app_description= ?, app_startdate= ?, app_enddate= ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym= ?";
    let editdata = [desc, startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
    console.log("BABABABABABABAABABAABABABA :", permitcreate);
    if (!desc && !startdate) {
      //if email is not changed
      conquery = "UPDATE application SET app_enddate = ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym = ?";
      editdata = [enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
      console.log("no desc and startdate");
    } else if (!desc && !enddate) {
      //if password is not changed, still same old
      conquery = "UPDATE application SET app_startdate= ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym = ?";
      editdata = [startdate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
    } else if (!startdate && !enddate) {
      conquery = "UPDATE application SET app_description= ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym = ?";
      editdata = [desc, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
    } else if (!desc) {
      conquery = "UPDATE application SET app_startdate= ?, app_enddate= ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym = ?";
      editdata = [startdate, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
    } else if (!startdate) {
      conquery = "UPDATE application SET app_description= ?, app_enddate= ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym = ?";
      editdata = [desc, enddate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
    } else if (!enddate) {
      conquery = "UPDATE application SET app_description= ?, app_startdate= ?, app_permit_create=?, app_permit_open=?, app_permit_todolist=?, app_permit_doing=?,app_permit_done=? WHERE app_acronym = ?";
      editdata = [desc, startdate, permitcreate, permitopen, permittodo, permitdoing, permitdone, acronym];
    } else if (!enddate && !startdate && !desc) {
      resolve("0");
    }
    con.query(conquery, editdata, (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error registering into database");
        resolve("0");
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successfully updated for application");
        resolve("1");
      }
    });
  });
};

exports.viewappgroupsFunction = () => {
  return new Promise((resolve, reject) => {
    console.log("hihhihihihi");
    con.query("SELECT * FROM `usergroup`", (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for User Groups");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of User Groups");
        resolve(result);
      } else {
        console.log("Unsuccessful retrieval of user groups");
      }
    });
  });
};

exports.createplanFunction = (mvpname, desc, startdate, enddate, acronym) => {
  return new Promise((resolve, reject) => {
    // con.query("SELECT * FROM `plans` WHERE `Plan_MVP_name` = ? and `Plan_app_Acronym` = ?", [mvpname, acronym], (error, result) => {
    //   if (result.length > 0) {
    //     //There is duplicate of app, send the message
    //     console.log("Duplicate Plan Name in the same App Acronym");
    //     resolve("0");
    //   } else {
    con.query("INSERT INTO plans (Plan_MVP_name,Plan_description,Plan_startDate,Plan_endDate,Plan_app_Acronym) VALUES (?,?,?,?,?)", [mvpname, desc, startdate, enddate, acronym], (error, result) => {
      //if error throw error
      if (result) {
        //There is duplicate, send the message
        console.log("Successfully registered to database");
        console.log(result, "controller insert");
        resolve("1");
      }
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error in creating plan, could be duplicates");
        resolve(error);
      }
      //if it is sending error, it won't proceed on
    });
  });
};
//     });
//   });
// };

exports.viewplansFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT Plan_MVP_name, Plan_Description, Plan_startDate, Plan_endDate FROM `plans` WHERE `Plan_app_Acronym` = ?", [acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of plans");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of plans related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.viewplanFunction = (acronym, mvpname) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT Plan_description, Plan_startDate, Plan_endDate FROM `plans` WHERE `Plan_app_Acronym` = ? and `Plan_MVP_name` = ?", [acronym, mvpname], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of plans");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of plans related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.createtaskFunction = (taskname, taskowner, desc, taskplan, state, taskid, creator, tasknotes, acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `task` WHERE `Task_name` = ? and 'Task_app_Acronym' = ?", [taskname, acronym], (error, result) => {
      if (result.length > 0) {
        //There is duplicate of app, send the message
        console.log("Duplicate Task Name");
        resolve("0");
      } else {
        if (taskplan.length < 1) {
          conquery = "INSERT INTO task (Task_name,Task_owner,Task_description,Task_state,Task_id,Task_creator,Task_notes,Task_app_Acronym) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
          insertdata = [taskname, taskowner, desc, state, taskid, creator, tasknotes, acronym];
        } else {
          conquery = "INSERT INTO task (Task_name,Task_owner,Task_description,Task_plan,Task_state,Task_id,Task_creator,Task_notes,Task_app_Acronym) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
          insertdata = [taskname, taskowner, desc, taskplan, state, taskid, creator, tasknotes, acronym];
        }
        con.query(conquery, insertdata, (error, result) => {
          //if error throw error
          if (result) {
            //There is duplicate, send the message
            console.log("Successfully registered to database");
            console.log(result, "controller insert");
            resolve("1");
          }
          if (error) {
            //Send to console that there is an error with database
            console.log(error);
            console.log("Error in creating plan, could be duplicates");
            resolve(error);
          }
          //if it is sending error, it won't proceed on
        });
      }
    });
  });
};

exports.viewtaskplansFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT Plan_MVP_name, Plan_Description FROM `plans` WHERE `Plan_app_Acronym` = ?", [acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of plans");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of plans related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.rnoFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT app_rnumber FROM `application` WHERE `app_acronym` = ?", [acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of plans");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of rnumber from applications");
        resolve(result);
      }
    });
  });
};

exports.rnotwoFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT COUNT(*) AS Task_name FROM `task` WHERE `Task_app_Acronym` = ?", [acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of plans");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successful Retrieval of rnumber from applications");
        resolve(result[0]);
      }
    });
  });
};

exports.viewtasksFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT Task_name, Task_description, Task_State, Task_id FROM `task` WHERE `Task_app_Acronym` = ?", [acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of tasks");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of tasks related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.edittaskFunction = (state, taskowner, taskname, acronym) => {
  return new Promise((resolve, reject) => {
    con.query("UPDATE task SET Task_state = ?, Task_owner= ? WHERE Task_name = ? and Task_app_Acronym = ?", [state, taskowner, taskname, acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Update");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("Successful Update of tasks related to the acronym");
        console.log(result);
        resolve(true);
      }
    });
  });
};

exports.fetchEditTaskFunction = (taskname, acronym) => {
  return new Promise((resolve, reject) => {
    sql_query = "SELECT Task_description, Task_notes, Task_owner, Task_id, Task_plan, Task_state, Task_creator, Task_createDate FROM `task` WHERE `Task_name` = ? and Task_app_Acronym = ?";
    con.query(sql_query, [taskname, acronym], (error, result) => {
      console.log(result);
      if (error) {
        console.log(error);
        console.log("Error Looking for Task");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("Successful Retrieval of Task Requested");
        resolve(result);
      } else {
        console.log("Application not found");
      }
    });
  });
};

exports.edittasksFunction = (desc, taskowner, taskplan, taskname, acronym) => {
  return new Promise((resolve, reject) => {
    let conquery = "UPDATE task SET Task_description= ?, Task_owner= ?, Task_plan=? WHERE Task_name= ? and Task_app_Acronym= ?";
    let editdata = [desc, taskowner, taskplan, taskname, acronym];
    con.query(conquery, editdata, (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error registering into database");
        resolve("0");
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successfully updated for task");
        resolve("1");
      }
    });
  });
};

exports.addcommentFunction = (tasknotes, taskname, acronym) => {
  return new Promise((resolve, reject) => {
    con.query("UPDATE task SET `Task_notes`=CONCAT(?,Task_notes) WHERE Task_name = ? and Task_app_Acronym = ?", [tasknotes, taskname, acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Updating");
        resolve("0");
      } //if it is sending error, it won't proceed on
      else {
        console.log("Successful Update of tasks related to the acronym woooo");
        resolve("1");
      }
    });
  });
};

exports.viewapppermitsFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT app_permit_create, app_permit_open, app_permit_todolist, app_permit_doing, app_permit_done FROM `application` WHERE `app_acronym` = ?", [acronym], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of permits");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of app permits related to the acronym");
        resolve(result);
      }
    });
  });
};

//For checkgroup Function
exports.getuserpermitsFunction = (username) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT belongsto FROM `accounts` WHERE `username` = ?", username, (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error. failed to get permits. Maybe SQL is down");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        // bcrypt.compare(password, result[0].password, (error, response) => {
        // if (response) {
        console.log("controller admin", result[0].belongsto); //outputs the usernames that are admin
        console.log("Retrieval Successful!");
        resolve(result[0].belongsto);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful retrieval");
        resolve(result);
      }
    });
  });
};

exports.editplanFunction = (desc, startdate, enddate, mvpname, acronym) => {
  return new Promise((resolve, reject) => {
    let conquery = "UPDATE plans SET Plan_description= ?, Plan_startDate= ?, Plan_endDate= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
    let editdata = [desc, startdate, enddate, mvpname, acronym];
    if (!desc && !startdate) {
      conquery = "UPDATE plans SET Plan_endDate= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
      editdata = [enddate, mvpname, acronym];
    } else if (!desc && !enddate) {
      conquery = "UPDATE plans SET Plan_startDate= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
      editdata = [startdate, mvpname, acronym];
    } else if (!startdate && !enddate) {
      conquery = "UPDATE plans SET Plan_description= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
      editdata = [desc, mvpname, acronym];
    } else if (!desc) {
      conquery = "UPDATE plans SET Plan_startDate= ?, Plan_endDate= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
      editdata = [startdate, enddate, mvpname, acronym];
      console.log("no new desc");
    } else if (!startdate) {
      //if password is not changed, still same old
      conquery = "UPDATE plans SET Plan_description= ?, Plan_endDate= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
      editdata = [desc, enddate, mvpname, acronym];
      console.log("no new start date");
    } else if (!enddate) {
      //if password is not changed, still same old
      conquery = "UPDATE plans SET Plan_description= ?, Plan_startDate= ? WHERE Plan_MVP_Name= ? and Plan_app_Acronym= ?";
      editdata = [desc, startdate, mvpname, acronym];
      console.log("no new end date");
    } else if (!startdate && !enddate && !desc) {
      resolve("0");
    }
    con.query(conquery, editdata, (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error registering into database");
        resolve("0");
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successfully updated for application");
        resolve("1");
      }
    });
  });
};

exports.PLFunction = (groupname) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT email FROM `accounts` WHERE belongsto LIKE ?", [groupname], (error, result) => {
      console.log(result, "MY PL RESULTS!!!!!"); //queries to take all accounts that has admin in belongsto column
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error, False");
        resolve(error);
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("controller admin", result[0]); //outputs the usernames that are admin
        console.log("Retrieval Successful, pulled all PLs");
        resolve(result);
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful, perhaps there is no PLs", result[0]);
        resolve(result);
      }
    });
  });
};

exports.fetchacroFunction = (acronym) => {
  return new Promise((resolve, reject) => {
    console.log("going into sql!!!!!");
    sql_query = "SELECT * FROM `application` WHERE `app_acronym` = ?";
    con.query(sql_query, [acronym], (error, result) => {
      console.log(result);
      if (error) {
        console.log(error);
        console.log("Error Looking for App");
        resolve("0");
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("Successful. App acronym exists");
        resolve(result);
      } else {
        console.log("Application not found");
        resolve("0");
      }
    });
  });
};

//For checkgroup Function
exports.checkgroupsFunction = (username, apppermscreate) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `accounts` WHERE `username` = ? and belongsto LIKE ?", [username, apppermscreate], (error, result) => {
      console.log(result, "SQL RESULTS"); //queries to take all accounts that has admin in belongsto column
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error, False");
        resolve("0");
      } //if it is sending error, it won't proceed on
      if (result.length > 0) {
        console.log("controller admin", result[0]); //outputs the usernames that are admin
        console.log("Retrieval Successful, checkgroups True");
        resolve("1");
      } else {
        // res.send({message:"Wrong username/Password combination!"});
        console.log("Unsuccessful, perhaps there is no permscreate", result[0]);
        resolve("0");
      }
    });
  });
};

exports.viewtaskplanstwoFunction = (acronym, taskplan) => {
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `plans` WHERE `Plan_app_Acronym` = ? and `Plan_MVP_name`= ?", [acronym, taskplan], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of plans");
        resolve(error);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of plans related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.viewtaskbystateFunction = (acronym, taskstate) => {
  return new Promise((resolve, reject) => {
    console.log("going into query!!!!!");
    con.query("SELECT * FROM `task` WHERE `Task_app_Acronym` = ? and `Task_State` = ?", [acronym, taskstate], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for list of tasks");
        resolve(false);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of tasks related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.fetchidFunction = (acronym, taskid) => {
  console.log("GOING INTO FETCHIDS YOHHHHHHHHH");
  return new Promise((resolve, reject) => {
    con.query("SELECT * FROM `task` WHERE `Task_app_Acronym` = ? and `Task_id` = ?", [acronym, taskid], (error, result) => {
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error Looking for taskid");
        resolve(false);
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result[0]);
        console.log("Successful Retrieval of taskid related to the acronym");
        resolve(result);
      }
    });
  });
};

exports.updatedoingtodoneFunction = (taskstate, acronym, taskid) => {
  return new Promise((resolve, reject) => {
    let conquery = "UPDATE task SET Task_state= ? WHERE Task_app_Acronym= ? and Task_id= ?";
    let editdata = [taskstate, acronym, taskid];
    con.query(conquery, editdata, (error, result) => {
      console.log(result);
      if (error) {
        //Send to console that there is an error with database
        console.log(error);
        console.log("Error registering into database");
        resolve("0");
      } //if it is sending error, it won't proceed on
      else {
        console.log("controller", result);
        console.log("Successfully updated for task");
        resolve("1");
      }
    });
  });
};
module.exports = exports;
