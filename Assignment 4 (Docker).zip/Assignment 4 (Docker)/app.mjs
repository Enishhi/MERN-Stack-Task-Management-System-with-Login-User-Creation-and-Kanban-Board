import express from "express";
const mysqlcon = require("./mysqlcon.js");
// import connectToDatabase from './helpers.mjs'
const controller = require("../controller/controller.js");
const app = express();
const cors = require("cors");

app.use(
  cors({
    origin: ["http://localhost:3000"],
    methods: ["GET", "POST"],
    credentials: true,
    optionSuccessStatus: 200,
  })
); //to parse requests of type app/json

app.get("/", (req, res) => {
  res.send("<h2> Hi there! </h2>");
});

// await connectToDatabase();

app.listen(3000);
