const { response } = require("express");
const { request } = require("http");
var mysql = require("mysql2");
const con = mysql.createPool({
  connectionLimit: 10,

  // host: "host.docker.internal",
  // // host: "localhost",
  // port: 3306,
  // user: "root",
  // password: "cdefg2",
  // database: "nodelogin",

  host: process.env.HOST,
  port: process.env.PORT,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
});
module.exports = con;
